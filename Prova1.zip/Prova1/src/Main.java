import model.*;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) {
        Secretaria secretaria = new Secretaria("12345",
                "Maria",
                "3351-1234",
                "mat001",
                LocalDate.of(2020,10,5));



        Medico medico = new Medico("1111",
                "Joao",
                "9999888",
                "CRM30000",
                "Cardiologista");

        Paciente paciente = new Paciente("2222",
                "Jose", "88888",
                "Rua tal",
                LocalDate.of(2000,9,28));

        Exame exame1 = new Exame("Colesterol");
        Exame exame2 = new Exame("Triglicerides");

        Medicamento medicamento1 = new Medicamento("Dipirona");
        Medicamento medicamento2 = new Medicamento("Diclofenaco");

        Consulta consulta1 = new Consulta(LocalDate.of(2022,9,20),
                        LocalTime.of(9,30),
                paciente, secretaria, medico);

        consulta1.adicionarMedicamento(medicamento1,medicamento2);
        consulta1.adicionarExame(exame1,exame2);

        paciente.adicionarConsulta(consulta1);

        paciente.exibirHistoricoConsulta();

        List<Pessoa> lista = new ArrayList<>();
        lista.add(medico);
        lista.add(secretaria);
        lista.add(paciente);

        for (Pessoa p: lista)
            p.mostrarDados();

    }
}