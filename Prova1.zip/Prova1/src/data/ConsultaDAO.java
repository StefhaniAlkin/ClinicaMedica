package data;

import model.Consulta;

import java.util.List;

public interface ConsultaDAO extends DAO<Consulta>{
    void  salvar(Consulta consulta);
    void atualizar (Consulta consulta);
    void apagar (Consulta consulta);
    Consulta buscar (int id);
    List<Consulta> buscarTodos();
}
