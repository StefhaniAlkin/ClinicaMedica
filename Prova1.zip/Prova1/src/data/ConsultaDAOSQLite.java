package data;

import model.Consulta;
import model.Medico;
import model.Paciente;
import model.Secretaria;


import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

public class ConsultaDAOSQLite implements ConsultaDAO {

    @Override
    public void salvar(Consulta consulta) {
        String sql = "INSERT INTO consulta values (?, ?, ?, ?, ?, ?)";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)) {
            stmt.setDate(1, Date.valueOf(consulta.getData()));
            stmt.setTime(2, Time.valueOf(consulta.getHora()));
            stmt.setString(3, consulta.getPaciente().getCpf());
            stmt.setString(4, consulta.getSecretaria().getCpf());
            stmt.setString(5, consulta.getMedico().getCpf());
            stmt.setInt(6, consulta.getIdConsulta());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Consulta consulta) {
        String sql = "UPDATE consulta SET data=?, hora=?, paciente=?, secretaria=?, medico=? WHERE idConsulta=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setDate(1, Date.valueOf(consulta.getData()));
            stmt.setTime(2, Time.valueOf(consulta.getHora()));
            stmt.setString(3, consulta.getPaciente().getCpf());
            stmt.setString(4, consulta.getSecretaria().getCpf());
            stmt.setString(5, consulta.getMedico().getCpf());
            stmt.setInt(6, consulta.getIdConsulta());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void apagar(Consulta consulta) {
        String sql = "DELETE FROM consulta WHERE idConsulta=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setInt(1,consulta.getIdConsulta());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Consulta buscar(int id) {
        Consulta consulta=null;
        String sql = "SELECT * FROM consulta WHERE idConsulta=?";
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)){
            stmt.setInt(1,id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Paciente paciente = new PacienteDAOSQLite().buscar(rs.getString("paciente"));
                Secretaria secretaria = new SecretariaDAOSQLite().buscar(rs.getString("secretaria"));
                Medico medico = new MedicoDAOSQLite().buscar(rs.getString("medico"));
                consulta = new Consulta(LocalDate.parse(rs.getString("data")), LocalTime.parse(rs.getString("hora")), paciente, secretaria, medico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return consulta;
    }

    @Override
    public List<Consulta> buscarTodos() {
        String sql = "SELECT * FROM consulta";
        List<Consulta> listaConsulta =new ArrayList<>();
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Paciente paciente = new PacienteDAOSQLite().buscar(rs.getString("paciente"));
                Secretaria secretaria = new SecretariaDAOSQLite().buscar(rs.getString("secretaria"));
                Medico medico = new MedicoDAOSQLite().buscar(rs.getString("medico"));
                Consulta consulta = new Consulta(LocalDate.parse(rs.getString("data")), LocalTime.parse(rs.getString("hora")), paciente, secretaria, medico);
                listaConsulta.add(consulta);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaConsulta;
    }
}
