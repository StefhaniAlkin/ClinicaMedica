package data;

import java.util.List;


public interface DAOCpf <T> {
    void salvar(T type);

    void atualizar(T type);

    void apagar(T type);

    T buscar(String id);

    List<T> buscarTodos();
}