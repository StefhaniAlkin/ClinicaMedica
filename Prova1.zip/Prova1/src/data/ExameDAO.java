package data;

import model.Exame;

import java.util.List;

public interface ExameDAO extends DAO<Exame>{
    void  salvar(Exame exame);
    void atualizar (Exame exame);
    void apagar (Exame exame);
    Exame buscar (int id);
    List<Exame> buscarTodos();
}
