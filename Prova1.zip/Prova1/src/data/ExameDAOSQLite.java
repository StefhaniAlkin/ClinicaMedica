package data;

import model.Exame;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ExameDAOSQLite implements ExameDAO {

    @Override
    public void salvar(Exame exame) {
        String sql = "INSERT INTO exame values (?)";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)) {
            stmt.setString(1, exame.getNomeExame());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Exame exame) {
        String sql = "UPDATE exame SET nomeExame=? WHERE idExame=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,exame.getNomeExame());
            stmt.setInt(1,exame.getIdExame());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void apagar(Exame exame) {
        String sql = "DELETE FROM exame WHERE idExame=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setInt(1,exame.getIdExame());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Exame buscar(int id) {
        Exame exame=null;
        String sql = "SELECT * FROM exame WHERE idExame=?";
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)){
            stmt.setInt(1,id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
                exame = new Exame(rs.getString("nomeExame"), rs.getInt("idExame"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return exame;
    }

    @Override
    public List<Exame> buscarTodos() {
        String sql = "SELECT * FROM exame";
        List<Exame> listaExame =new ArrayList<>();
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Exame exame = new Exame(rs.getString("nomeExame"), rs.getInt("idExame"));
                listaExame.add(exame);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaExame;
    }
}
