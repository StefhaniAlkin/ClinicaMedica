package data;

import model.Medicamento;

import java.util.List;

public interface MedicamentoDAO extends DAO<Medicamento> {
    void  salvar(Medicamento medicamento);
    void atualizar (Medicamento medicamento);
    void apagar (Medicamento medicamento);
    Medicamento buscar (int id);
    List<Medicamento> buscarTodos();
}
