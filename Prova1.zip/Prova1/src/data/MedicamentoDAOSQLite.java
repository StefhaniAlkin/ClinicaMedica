package data;

import model.Medicamento;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicamentoDAOSQLite implements MedicamentoDAO {

    @Override
    public void salvar(Medicamento medicamento) {
        String sql = "INSERT INTO medicamento values (?)";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)) {
            stmt.setString(1, medicamento.getNomeMedicamento());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Medicamento medicamento) {
        String sql = "UPDATE medicamento SET nomeMedicamento=? WHERE idMedicamento=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,medicamento.getNomeMedicamento());
            stmt.setInt(1,medicamento.getIdMedicamento());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void apagar(Medicamento medicamento) {
        String sql = "DELETE FROM medicamento WHERE idMedicamento=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setInt(1,medicamento.getIdMedicamento());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Medicamento buscar(int id) {
        Medicamento medicamento=null;
        String sql = "SELECT * FROM medicamento WHERE idMedicamento=?";
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)){
            stmt.setInt(1,id);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
                medicamento = new Medicamento(rs.getString("nomeMedicamento"), rs.getInt("idMedicamento"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medicamento;
    }

    @Override
    public List<Medicamento> buscarTodos() {
        String sql = "SELECT * FROM medicamento";
        List<Medicamento> listaMedicamento =new ArrayList<>();
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Medicamento medicamento = new Medicamento(rs.getString("nomeMedicamento"), rs.getInt("idMedicamento"));
                listaMedicamento.add(medicamento);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaMedicamento;
    }
}
