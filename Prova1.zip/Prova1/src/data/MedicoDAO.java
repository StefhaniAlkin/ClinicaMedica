package data;

import model.Medicamento;
import model.Medico;

import java.util.List;

public interface MedicoDAO extends DAOCpf<Medico> {
    void  salvar(Medico medico);
    void atualizar (Medico medico);
    void apagar (Medico medico);
    Medico buscar (String cpf);
    List<Medico> buscarTodos();
}
