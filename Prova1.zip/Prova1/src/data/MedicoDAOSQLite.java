package data;

import model.Medico;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MedicoDAOSQLite implements MedicoDAO {

    @Override
    public void salvar(Medico medico) {
        String sql = "INSERT INTO medico values (?, ?, ?, ?, ?)";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)) {
            stmt.setString(1, medico.getCpf());
            stmt.setString(2, medico.getNome());
            stmt.setString(3, medico.getTelefone());
            stmt.setString(4, medico.getEspecialidade());
            stmt.setString(5, medico.getNumCRM());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Medico medico) {
        String sql = "UPDATE medico SET cpf=?, nome=?, telefone=?, especialidade=?, numCRM=? WHERE cpf=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1, medico.getCpf());
            stmt.setString(2, medico.getNome());
            stmt.setString(3, medico.getTelefone());
            stmt.setString(4, medico.getEspecialidade());
            stmt.setString(5, medico.getNumCRM());
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void apagar(Medico medico) {
        String sql = "DELETE FROM medico WHERE cpf=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,medico.getCpf());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Medico buscar(int id) {
        return null;
    }

    @Override
    public Medico buscar(String cpf) {
        Medico medico=null;
        String sql = "SELECT * FROM medico WHERE cpf=?";
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,cpf);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
                medico = new Medico(rs.getString("cpf"), rs.getString("nome"), rs.getString("telefone"), rs.getString("especialidade"), rs.getString("numCRM"));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return medico;
    }

    @Override
    public List<Medico> buscarTodos() {
        String sql = "SELECT * FROM medico";
        List<Medico> listaMedico =new ArrayList<>();
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Medico medico = new Medico(rs.getString("cpf"), rs.getString("nome"), rs.getString("telefone"), rs.getString("especialidade"), rs.getString("numCRM"));
                listaMedico.add(medico);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaMedico;
    }
}
