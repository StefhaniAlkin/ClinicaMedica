package data;

import model.Paciente;

import java.util.List;

public interface PacienteDAO extends DAOCpf<Paciente>{
    void  salvar(Paciente paciente);
    void atualizar (Paciente paciente);
    void apagar (Paciente paciente);
    Paciente buscar (String id);
    List<Paciente> buscarTodos();
}
