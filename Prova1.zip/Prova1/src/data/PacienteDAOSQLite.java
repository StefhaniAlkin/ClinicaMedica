package data;

import model.Paciente;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class PacienteDAOSQLite implements PacienteDAO {

    @Override
    public void salvar(Paciente paciente) {
        String sql = "INSERT INTO paciente values (?, ?, ?, ?, ?)";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)) {
            stmt.setString(1, paciente.getCpf());
            stmt.setString(2, paciente.getNome());
            stmt.setString(3, paciente.getTelefone());
            stmt.setString(4, paciente.getEndereco());
            stmt.setDate(5, Date.valueOf(paciente.getDataNascimento()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Paciente paciente) {
        String sql = "UPDATE paciente SET cpf=?, nome=?, telefone=?, endereco=?, dataNascimento=? WHERE cpf=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1, paciente.getCpf());
            stmt.setString(2, paciente.getNome());
            stmt.setString(3, paciente.getTelefone());
            stmt.setString(4, paciente.getEndereco());
            stmt.setDate(5, Date.valueOf(paciente.getDataNascimento()));
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void apagar(Paciente paciente) {
        String sql = "DELETE FROM paciente WHERE cpf=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,paciente.getCpf());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Paciente buscar(int id) {
        return null;
    }

    @Override
    public Paciente buscar(String cpf) {
        Paciente paciente=null;
        String sql = "SELECT * FROM paciente WHERE cpf=?";
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,cpf);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
                paciente = new Paciente(rs.getString("cpf"), rs.getString("nome"), rs.getString("telefone"), rs.getString("endereco"), LocalDate.parse(rs.getString("dataNascimento")));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return paciente;
    }

    @Override
    public List<Paciente> buscarTodos() {
        String sql = "SELECT * FROM paciente";
        List<Paciente> listaPaciente =new ArrayList<>();
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Paciente paciente = new Paciente(rs.getString("cpf"), rs.getString("nome"), rs.getString("telefone"), rs.getString("endereco"), LocalDate.parse(rs.getString("dataNascimento")));
                listaPaciente.add(paciente);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaPaciente;
    }
}
