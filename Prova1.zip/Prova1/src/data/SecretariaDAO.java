package data;

import model.Secretaria;

import java.util.List;

public interface SecretariaDAO extends DAOCpf<Secretaria>{
    void  salvar(Secretaria secretaria);
    void atualizar (Secretaria secretaria);
    void apagar (Secretaria secretaria);

    Secretaria buscar(int id);

    Secretaria buscar (String id);
    List<Secretaria> buscarTodos();
}
