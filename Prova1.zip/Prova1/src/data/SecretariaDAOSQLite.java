package data;

import model.Secretaria;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class SecretariaDAOSQLite implements SecretariaDAO {

    @Override
    public void salvar(Secretaria secretaria) {
        String sql = "INSERT INTO secretaria values (?, ?, ?, ?, ?)";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)) {
            stmt.setString(1, secretaria.getCpf());
            stmt.setString(2, secretaria.getNome());
            stmt.setString(3, secretaria.getTelefone());
            stmt.setString(4, secretaria.getMatriculaFuncional());
            stmt.setDate(5, Date.valueOf(secretaria.getDataAdmissao()));
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void atualizar(Secretaria secretaria) {
        String sql = "UPDATE secretaria SET cpf=?, nome=?, telefone=?, matriculaFuncional=?, dataAdmissao=? WHERE cpf=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1, secretaria.getCpf());
            stmt.setString(2, secretaria.getNome());
            stmt.setString(3, secretaria.getTelefone());
            stmt.setString(4, secretaria.getMatriculaFuncional());
            stmt.setDate(5, Date.valueOf(secretaria.getDataAdmissao()));
            stmt.executeUpdate();

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    public void apagar(Secretaria secretaria) {
        String sql = "DELETE FROM secretaria WHERE cpf=?";
        try(PreparedStatement stmt=ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,secretaria.getCpf());
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Secretaria buscar(int id) {
        return null;
    }

    @Override
    public Secretaria buscar(String cpf) {
        Secretaria secretaria=null;
        String sql = "SELECT * FROM secretaria WHERE cpf=?";
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)){
            stmt.setString(1,cpf);
            ResultSet rs = stmt.executeQuery();
            while (rs.next())
                secretaria = new Secretaria(rs.getString("cpf"), rs.getString("nome"), rs.getString("telefone"), rs.getString("matriculaFuncional"), LocalDate.parse(rs.getString("dataAdmissao")));

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return secretaria;
    }

    @Override
    public List<Secretaria> buscarTodos() {
        String sql = "SELECT * FROM secretaria";
        List<Secretaria> listaSecretaria =new ArrayList<>();
        try(PreparedStatement stmt = ConnectionFactory.criaStatement(sql)) {
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                Secretaria secretaria = new Secretaria(rs.getString("cpf"), rs.getString("nome"), rs.getString("telefone"), rs.getString("matriculaFuncional"), LocalDate.parse(rs.getString("dataAdmissao")));
                listaSecretaria.add(secretaria);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return listaSecretaria;
    }
}
