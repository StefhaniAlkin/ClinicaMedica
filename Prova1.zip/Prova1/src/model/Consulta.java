package model;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class Consulta {
    private LocalDate data;
    private LocalTime hora;
    private Paciente paciente;
    private Secretaria secretaria;
    private Medico medico;
    private List<Exame> exame = new ArrayList<>();
    private List<Medicamento> medicamento = new ArrayList<>();
    private int idConsulta;

    public Consulta(LocalDate data, LocalTime hora, Paciente paciente, Secretaria secretaria, Medico medico, List<Exame> exame, List<Medicamento> medicamento) {
        this.data = data;
        this.hora = hora;
        this.paciente = paciente;
        this.secretaria = secretaria;
        this.medico = medico;
        this.exame = exame;
        this.medicamento = medicamento;
    }

    public Consulta(LocalDate data, LocalTime hora, Paciente paciente, Secretaria secretaria, Medico medico) {
        this.data = data;
        this.hora = hora;
        this.paciente = paciente;
        this.secretaria = secretaria;
        this.medico = medico;
    }

    public Consulta(LocalDate data, LocalTime hora, List<Exame> exame, List<Medicamento> medicamento) {
        this.data = data;
        this.hora = hora;
        this.exame = exame;
        this.medicamento = medicamento;
    }

    public LocalDate getData() {
        return data;
    }

    public void setData(LocalDate data) {
        this.data = data;
    }

    public LocalTime getHora() {
        return hora;
    }

    public void setHora(LocalTime hora) {
        this.hora = hora;
    }

    public Paciente getPaciente() {
        return paciente;
    }

    public void setPaciente(Paciente paciente) {
        this.paciente = paciente;
    }

    public Secretaria getSecretaria() {
        return secretaria;
    }

    public void setSecretaria(Secretaria secretaria) {
        this.secretaria = secretaria;
    }

    public Medico getMedico() {
        return medico;
    }

    public void setMedico(Medico medico) {
        this.medico = medico;
    }

    public List<Exame> getExame() {
        return exame;
    }

    public void setExame(List<Exame> exame) {
        this.exame = exame;
    }

    public List<Medicamento> getMedicamento() {
        return medicamento;
    }

    public void setMedicamento(List<Medicamento> medicamento) {
        this.medicamento = medicamento;
    }

    public int getIdConsulta() {
        return idConsulta;
    }

    public void setIdConsulta(int idConsulta) {
        this.idConsulta = idConsulta;
    }

    public void adicionarMedicamento(Medicamento... med ){
        for (Medicamento m : med)
            this.medicamento.add(m);
    }
    public void adicionarExame(Exame... exam){
        for (Exame e:exam)
            this.exame.add(e);
    }

    public void mostrarDados(){
        System.out.println("\n Data: " + this.getData().format(DateTimeFormatter.ofPattern("dd/MM/yyyy")) +
                "\n Hora: " + this.getHora() +
                "\n Secretaria: " + this.getSecretaria().getNome() +
                "\n Medico: " + this.getMedico().getNome() +
                "\n Paciente: " + this.getPaciente().getNome() );
        System.out.println("\n Medicamentos: ");
        for (Medicamento m: medicamento)
            System.out.println(m.getNomeMedicamento());

        System.out.println("\n Exames: ");
        for (Exame e: exame)
            System.out.println(e.getNomeExame());
    }

}
