package model;

public class Exame {
    private String nomeExame;
    private int idExame;

    public Exame(String nomeExame, int idExame) {
        this.nomeExame = nomeExame;
        this.idExame = idExame;
    }

    public Exame(int idExame) {
        this.idExame = idExame;
    }

    public Exame(String nomeExame) {
        this.nomeExame = nomeExame;
    }

    public String getNomeExame() {
        return nomeExame;
    }

    public void setNomeExame(String nomeExame) {
        this.nomeExame = nomeExame;
    }

    public int getIdExame() {
        return idExame;
    }

    public void setIdExame(int idExame) {
        this.idExame = idExame;
    }
}
