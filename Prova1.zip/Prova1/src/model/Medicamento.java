package model;

public class Medicamento {
    private String nomeMedicamento;
    private int idMedicamento;

    public Medicamento(String nomeMedicamento, int idMedicamento) {
        this.nomeMedicamento = nomeMedicamento;
        this.idMedicamento = idMedicamento;
    }
    public Medicamento(String nomeMedicamento) {
        this.nomeMedicamento = nomeMedicamento;
    }
    public Medicamento(int idMedicamento) {
        this.idMedicamento = idMedicamento;
    }


    public String getNomeMedicamento() {
        return nomeMedicamento;
    }

    public void setNomeMedicamento(String nomeMedicamento) {
        this.nomeMedicamento = nomeMedicamento;
    }

    public int getIdMedicamento() {
        return idMedicamento;
    }

    public void setIdMedicamento(int idMedicamento) {
        this.idMedicamento = idMedicamento;
    }
}
