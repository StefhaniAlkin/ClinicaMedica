package model;

public class Medico extends Pessoa{
    private String numCRM;
    private String especialidade;

    public Medico(String cpf, String nome, String telefone, String numCRM, String especialidade) {
        super(cpf, nome, telefone);
        this.numCRM = numCRM;
        this.especialidade = especialidade;
    }

    public String getNumCRM() {
        return numCRM;
    }

    public void setNumCRM(String numCRM) {
        this.numCRM = numCRM;
    }

    public String getEspecialidade() {
        return especialidade;
    }

    public void setEspecialidade(String especialidade) {
        this.especialidade = especialidade;
    }

    @Override
    public void mostrarDados() {
        System.out.println("\nMedico : Mostrar Dados");
        System.out.println("\nNome: " + this.getNome());
        System.out.println("\nCPF: " + this.getCpf());
        System.out.println("\nTelefone: " + this.getTelefone());
        System.out.println("\nEspecialidade: " + this.getEspecialidade());
        System.out.println("\nCRM: " + this.getNumCRM());
    }
}
