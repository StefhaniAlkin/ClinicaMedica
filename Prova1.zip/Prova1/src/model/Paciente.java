package model;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class Paciente extends Pessoa{
    private String endereco;
    private LocalDate dataNascimento;
    private List<Consulta> consulta = new ArrayList<>();

    public Paciente(String cpf, String nome, String telefone, String endereco, LocalDate dataNascimento) {
        super(cpf, nome, telefone);
        this.endereco = endereco;
        this.dataNascimento = dataNascimento;
        this.consulta = consulta;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public LocalDate getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(LocalDate dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public List<Consulta> getConsulta() {
        return consulta;
    }

    public void setConsulta(List<Consulta> consulta) {
        this.consulta = consulta;
    }

    public void adicionarConsulta(Consulta... consulta){
        for (Consulta c: consulta){
            this.consulta.add(c);
        }
    }
    public void removerConsulta(Consulta... consulta){
        for (Consulta c: consulta){
            this.consulta.remove(c);
        }
    }
    @Override
    public void mostrarDados() {
        System.out.println("\nPaciente : Mostrar Dados");
        System.out.println("\nNome: " + this.getNome());
        System.out.println("\nCPF: " + this.getCpf());
        System.out.println("\nTelefone: " + this.getTelefone());
        System.out.println("\nEndereco: " + this.getEndereco());
        System.out.println("\nData Nascimento: " + this.getDataNascimento());
        System.out.println("\nConsultas: ");
        exibirHistoricoConsulta();
    }

    public void exibirHistoricoConsulta(){
        for (Consulta c: consulta){
            c.mostrarDados();
        }

    }
}
