package model;

import java.time.LocalDate;

public class Secretaria extends Pessoa{
    private String matriculaFuncional;
    private LocalDate dataAdmissao;

    public Secretaria(String cpf, String nome, String telefone, String matriculaFuncional, LocalDate dataAdmissao) {
        super(cpf, nome, telefone);
        this.matriculaFuncional = matriculaFuncional;
        this.dataAdmissao = dataAdmissao;
    }

    public String getMatriculaFuncional() {
        return matriculaFuncional;
    }

    public void setMatriculaFuncional(String matriculaFuncional) {
        this.matriculaFuncional = matriculaFuncional;
    }

    public LocalDate getDataAdmissao() {
        return dataAdmissao;
    }

    public void setDataAdmissao(LocalDate dataAdmissao) {
        this.dataAdmissao = dataAdmissao;
    }

    @Override
    public void mostrarDados() {
        System.out.println("\nSecretaria : Mostrar Dados");
        System.out.println("\nNome: " + this.getNome());
        System.out.println("\nCPF: " + this.getCpf());
        System.out.println("\nTelefone: " + this.getTelefone());
        System.out.println("\nMatricula Funcional: " + this.getMatriculaFuncional());
        System.out.println("\nData Admissao: " + this.getDataAdmissao());
    }
}
